﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Enums
{
    public class PageEnums
    {

        public enum PageType
        {
            Directory=0,
            Material=1
        }
    }
}
