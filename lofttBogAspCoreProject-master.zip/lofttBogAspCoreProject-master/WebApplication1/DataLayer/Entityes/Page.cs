﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataLayer.Entityes
{
    public class Page
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Html { get; set; }
    }
}
